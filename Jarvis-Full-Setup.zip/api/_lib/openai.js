const OPENAI_URL = "https://api.openai.com/v1/responses";

export async function askJarvis({ message, history = [] }) {
  const key = process.env.OPENAI_API_KEY;
  if (!key) {
    const error = new Error("OPENAI_API_KEY is not configured");
    error.status = 500;
    throw error;
  }

  const model = process.env.OPENAI_MODEL || "gpt-6-luna";

  const safeHistory = Array.isArray(history)
    ? history
        .filter(
          (x) =>
            x &&
            (x.role === "user" || x.role === "assistant") &&
            typeof x.content === "string"
        )
        .slice(-16)
    : [];

  const response = await fetch(OPENAI_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${key}`,
    },
    body: JSON.stringify({
      model,
      instructions: `
You are JARVIS, a personal AI assistant.

Languages:
- Gujarati
- Hindi
- Hinglish
- English

Rules:
1. Reply in the user's language/style when practical.
2. Be useful, concise, and honest.
3. Never claim an action was completed unless the application actually completed it.
4. For phone/app actions, return a clear intent such as:
   ACTION:OPEN_APP:<package_name>
   or ACTION:NONE
   followed by a short natural-language reply.
5. Do not request or expose API keys, passwords, OTPs, PINs, or private credentials.
6. For market questions, explain data/time context and do not present guesses as guaranteed outcomes.
7. You are the reasoning brain; the Android app performs local device actions.
`,
      input: [...safeHistory, { role: "user", content: message.trim() }],
      max_output_tokens: 1000,
    }),
  });

  const data = await response.json();

  if (!response.ok) {
    const error = new Error(
      data?.error?.message || "OpenAI request failed"
    );
    error.status = response.status;
    throw error;
  }

  const text = (data.output_text || "").trim();
  if (!text) {
    const error = new Error("Empty AI response");
    error.status = 502;
    throw error;
  }

  return { reply: text, model };
}
